<?php

return [
    'steadfast' => [
        'email' => 'unisalemart890@gmail.com',
        'password' => 'Babla2k12@#$%',
    ],

    'redx' => [
        'phone' => '01648811536',
        'password' => 'DnBRedx2025$',
        'token_file' => public_path('cache/redx_token.cache'),
    ],

    'pathao' => [
        'client_id' => 'APdRlXYaGy',
        'client_secret' => 'dkWMLtqJbTvOemaWwBwhy6bmDC6zv75AzCbKcqlS',
        'username' => 'stylisfirst@gmail.com',
        'password' => 'STYLIS@22bd',
        'token_file' => public_path('cache/pathao_token.json'),
    ],

    'logos' => [
        'pathao' => 'images/logo.svg',
        'steadfast' => 'images/logo.svg',
        'redx' => 'images/logo.svg',
        'paperfly' => 'images/logo.svg',
    ],
];
